These Gerber files were used for the v1 board, production date 2019-10-18
there are a couple of minor errors spotted after manufacture;

IBT2
the IS and EN pin order is wrong.
both EN pins should be connected together, one is floating.   Solder a wire between the two.

Also, if a shunt resistor (for analogue current monitoring) is fitted it will interfere with the IS pin.  
Generally you would not do this because it is better to use the INA914 current monitor chip.
This means the IBT2 supply must be commoned into the supply header hence no need to fit a second header.
EN is high to enable power

L298
I mislabelled EN as INH. we should have ENA and ENB and these are active high to enable power.
Instead they are labelled as INHA and INHB.

LMD
is corrrect.  PWM goes active high to enable power.


OTHER CONSIDERATIONS
heatsink holes are too large, centered too far back from tab.  they also are slightly out of alignment, perhaps by just 0.1mm

c4 tracks can be rerouted
LMD power tracks can be simplified, supply should come off C1
LMD heatsink should move inboard a few more mm

5v rail on the board should be post-jumper so the I2C can still be powered from USB (right now that is true only for its 3v3 supply).

R6 holes are too small, also track can be simplified.  also it could have an alternate position under the INA914 which its mutually exclusive with.

R4 pull up may be an error, or we can leave it as optional.

INA will fit better if it moves down by 0.1in

C1 can shift right 0.1

if no INA is used and we want either on or offboard bridge, we need a jumper between + and -.  This can be denoted in tPlace as a line with link1 

some of the tracks near the ESP can be simplified.  one is routed too close to the support hole.

Also check the jog-pushbutton requirement. is it pull up or down?
